﻿export interface IStatus {
    Id: number,
    status: string

}