﻿import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

import { IStatus } from './status';

@Injectable()
export class StatusService {
    private _apiUrl = 'http://localhost:61545/api/statuses';

    constructor(private _http: Http) { }


    getStatuses(): Observable<IStatus[]> {
        return this._http.get(this._apiUrl)
            .map((response: Response) => <IStatus[]>response.json());
        //.do(data => console.log('All: ' + JSON.stringify(data)))
        //.catch(this.handleError);
    }    
}