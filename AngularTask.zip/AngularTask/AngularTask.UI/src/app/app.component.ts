import { Component } from '@angular/core';

@Component({
    selector: 'bc-app',
    template: `        
        <navbar></navbar>
        <section class="container">            
            <router-outlet></router-outlet>
        </section>
    `
})
export class AppComponent {
    pageTitle: string = 'Angular Task Sample Management';
}
