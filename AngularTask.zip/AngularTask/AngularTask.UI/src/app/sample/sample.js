"use strict";
var Sample = (function () {
    function Sample() {
    }
    return Sample;
}());
exports.Sample = Sample;
//# sourceMappingURL=sample.js.map