﻿export interface ISample {
    userId: number,
    user: string,
    barcode: string,
    datedCreated: string,
    sampleId: number,
    status: string    
}

export class Sample {
    barcode: string;
    createdAt: string;
    createdBy: number;
    statusId: number;
}