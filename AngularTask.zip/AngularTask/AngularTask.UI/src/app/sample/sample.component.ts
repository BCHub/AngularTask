﻿
import { Component, OnInit } from '@angular/core';

import { ISample } from './sample';
import { SampleService }       from './sample.service';





@Component({
    templateUrl: 'app/sample/sample.component.html'
})

export class SampleComponent implements OnInit {
    samples: ISample[];


    tableFilter: string;
    errorMessage: string;

    constructor(private _sampleService: SampleService) {

    }


    ngOnInit(): void {
        this._sampleService.getSamples()
            .subscribe(samples => this.samples = samples,
            error => this.errorMessage = <any>error);        
    }
    
}