"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var sample_component_1 = require("./sample.component");
var sample_form_component_1 = require("./sample-form.component");
var sample_service_1 = require("./sample.service");
var status_service_1 = require("../status/status.service");
var shared_module_1 = require("../shared/shared.module");
var sample_filter_pipe_1 = require("./sample-filter.pipe");
var SampleModule = (function () {
    function SampleModule() {
    }
    return SampleModule;
}());
SampleModule = __decorate([
    core_1.NgModule({
        imports: [
            router_1.RouterModule.forChild([
                { path: 'samples', component: sample_component_1.SampleComponent },
                { path: 'samples/new', component: sample_form_component_1.SampleFormComponent }
            ]),
            shared_module_1.SharedModule
        ],
        declarations: [
            sample_component_1.SampleComponent,
            sample_form_component_1.SampleFormComponent,
            sample_filter_pipe_1.SampleFilterPipe
        ],
        providers: [
            /** Service Goes Here **/
            sample_service_1.SampleService,
            status_service_1.StatusService
        ]
    })
], SampleModule);
exports.SampleModule = SampleModule;
//# sourceMappingURL=sample.module.js.map