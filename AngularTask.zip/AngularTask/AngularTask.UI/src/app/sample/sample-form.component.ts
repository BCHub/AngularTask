﻿import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { Sample } from './sample';

import { StatusService } from '../status/status.service';
import { SampleService } from './sample.service';

import { IStatus } from '../status/status';


@Component({
    templateUrl: 'app/sample/sample-form.component.html'
})


export class SampleFormComponent implements OnInit {
    sampleForm: FormGroup;
    sample = new Sample();
    statuses: IStatus[];

    isSaved: boolean;


    constructor(fbuilder: FormBuilder,
        private _statusService: StatusService,
        private _sampleService: SampleService,
        private _router: Router) {

        this.sampleForm = fbuilder.group({
            barcode: ['', Validators.required],
            statusId: ['', Validators.required]
        });
    }

    
    ngOnInit() {
        this._statusService.getStatuses()
            .subscribe(statuses => this.statuses = statuses);
    }


    save() {

        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1;
        var yyyy = today.getFullYear();
        var currentDate = yyyy + '-' + mm + '-' + dd;

        this.sample.createdAt = currentDate;
        this.sample.createdBy = 4; //Assuming this Id is for the current user logged in
        this._sampleService.addSample(this.sample);       

        this.isSaved = true;
        this.sampleForm.reset();
           
    }
}