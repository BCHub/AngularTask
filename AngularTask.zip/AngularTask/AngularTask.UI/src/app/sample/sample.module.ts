﻿import { NgModule } from '@angular/core';
import { RouterModule} from '@angular/router';

import { SampleComponent } from './sample.component';
import { SampleFormComponent } from './sample-form.component';
import { SampleService } from './sample.service';
import { StatusService } from '../status/status.service';

import { SharedModule } from '../shared/shared.module';
import { SampleFilterPipe } from './sample-filter.pipe';


@NgModule({
    imports: [        
        RouterModule.forChild([
            { path: 'samples', component: SampleComponent },    
            { path: 'samples/new', component: SampleFormComponent }        
        ]),
        SharedModule
    ],
    declarations: [
        SampleComponent,
        SampleFormComponent,
        SampleFilterPipe
       
    ],
    providers: [
        /** Service Goes Here **/
        SampleService,
        StatusService
    ]
})
export class SampleModule { }

