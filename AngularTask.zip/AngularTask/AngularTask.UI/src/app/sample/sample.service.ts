﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';


import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

import { ISample } from './sample';
import { Sample } from './sample';

@Injectable()
export class SampleService {
    private _apiUrl = 'http://localhost:61545/api/samples';

    constructor(private _http: Http) { }


    getSamples(): Observable<ISample[]> {
        return this._http.get(this._apiUrl)
            .map((response: Response) => <ISample[]>response.json());
            //.do(data => console.log('All: ' + JSON.stringify(data)))
            //.catch(this.handleError);
    }


   

    addSample(sample: Sample) {

        var options = new Headers();
        options.append('Content-Type', 'application/json');

        return this._http.post(this._apiUrl, JSON.stringify(sample), { headers: options })
            .subscribe();
        
    }
}