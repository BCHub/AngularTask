﻿using AngularTask.Api.Core.Entities;
using AngularTask.Api.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularTask.Api.Services
{
    public interface ISampleService
    {
        List<SampleDto> GetSampleDtos();

        void AddSample(Sample sample);       
    }
}
