﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AngularTask.Api.DTOs;
using AngularTask.Api.Concrete;
using AngularTask.Api.Core.Entities;

namespace AngularTask.Api.Services.Concrete
{
    public class SampleService : ISampleService
    {
        public void AddSample(Sample sample)
        {
            using (var unitOfWork = new UnitOfWork(new TaskDbContext()))
            {
                unitOfWork.Samples.Insert(sample);
                unitOfWork.Complete();               
            }
        }



        public List<SampleDto> GetSampleDtos()
        {
            List<SampleDto> lstSamples = new List<SampleDto>();
            
            using (var unitOfWork = new UnitOfWork(new TaskDbContext()))
            {                

                var result = unitOfWork.Samples.GetSamplesWithUsersAndStatuses().OrderByDescending(x => x.CreatedAt).Select(x =>
                            new SampleDto()
                            {
                                UserId = x.CreatedBy,
                                User = x.CreatedByNavigation.FirstName + " " + x.CreatedByNavigation.LastName,
                                Barcode = x.Barcode,
                                DateCreated = x.CreatedAt.ToString(),
                                StatusId = x.StatusId,
                                Status = x.Status.StatusName
                            });
                lstSamples = result.ToList();  
            }
            return lstSamples;

        }

        
    }
}
