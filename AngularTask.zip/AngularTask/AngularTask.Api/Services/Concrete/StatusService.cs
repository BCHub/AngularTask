﻿using System;
using System.Collections.Generic;
using System.Linq;

using AngularTask.Api.Concrete;
using AngularTask.Api.DTOs;

namespace AngularTask.Api.Services.Concrete
{
    public class StatusService : IStatusService
    {
        public List<StatusDto> GetStatusDtos()
        {
            List<StatusDto> lstStatus = new List<StatusDto>();

            using (var unitOfWork = new UnitOfWork(new TaskDbContext()))
            {
                var result = unitOfWork.Statuses.GetAll();

                lstStatus = result.Select(x => new StatusDto((int)x.Id, x.StatusName)).ToList(); 
            }

            return lstStatus;
        }
    }
}
