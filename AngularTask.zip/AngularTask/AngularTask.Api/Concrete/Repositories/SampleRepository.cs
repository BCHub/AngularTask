﻿using AngularTask.Api.Core.Entities;
using AngularTask.Api.Core.Repositories;
using AngularTask.Api.DTOs;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularTask.Api.Concrete.Repositories
{
    public class SampleRepository : RepositoryBase<Sample>, ISampleRepository
    {
        public SampleRepository(TaskDbContext context) : base(context)
        {

        }


        public IEnumerable<Sample> GetSamplesWithUsersAndStatuses()
        {           
            return TaskDbContext.Sample.Include(s => s.Status).Include(u => u.CreatedByNavigation).ToList();
        }


        public TaskDbContext TaskDbContext
        {
            get { return _Context as TaskDbContext; }
        }
    }
}
