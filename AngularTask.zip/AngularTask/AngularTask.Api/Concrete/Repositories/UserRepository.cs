﻿using AngularTask.Api.Core.Entities;
using AngularTask.Api.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularTask.Api.Concrete.Repositories
{
    public class UserRepository : RepositoryBase<User>, IUserRepository
    {

        public UserRepository(TaskDbContext context) : base(context)
        {

        }

        public IEnumerable<User> GetUserWithSamplesAndStatuses()
        {
            throw new NotImplementedException();
        }


        public TaskDbContext TaskDbContext
        {
            get { return _Context as TaskDbContext; }
        }
    }
}
