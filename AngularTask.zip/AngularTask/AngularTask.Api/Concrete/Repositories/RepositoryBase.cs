﻿using AngularTask.Api.Core.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace AngularTask.Api.Concrete.Repositories
{
    public class RepositoryBase<TEntity> : IRepositoryBase<TEntity> where TEntity : class
    {
        protected readonly DbContext _Context;
        public RepositoryBase(DbContext context)
        {
            _Context = context;
        }



        public void Insert(TEntity entity)
        {
            _Context.Set<TEntity>().Add(entity);
        }

        public void InsertRange(IEnumerable<TEntity> entities)
        {
            _Context.Set<TEntity>().AddRange(entities);
        }



        public IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> predicate)
        {
            return _Context.Set<TEntity>().Where(predicate);
        }



        public TEntity Get(int id)
        {
            return null; // _Context.Set<TEntity>().Find(id); [ Missing From EF Core ]
        }



        public IEnumerable<TEntity> GetAll()
        {
            return _Context.Set<TEntity>();
        }



        public void Remove(TEntity entity)
        {
            _Context.Set<TEntity>().Remove(entity);
        }



        public void RemoveRange(IEnumerable<TEntity> entities)
        {
            _Context.Set<TEntity>().RemoveRange(entities);
        }



        public TEntity SingleOrDefault(Expression<Func<TEntity, bool>> predicate)
        {
            return _Context.Set<TEntity>().SingleOrDefault(predicate);
        }
    }
}
