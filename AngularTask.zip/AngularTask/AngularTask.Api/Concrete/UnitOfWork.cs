﻿using AngularTask.Api.Concrete.Repositories;
using AngularTask.Api.Core;
using AngularTask.Api.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularTask.Api.Concrete
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly TaskDbContext _context;
        public UnitOfWork(TaskDbContext context)
        {
            _context = context;
            Samples = new SampleRepository(_context);
            Users = new UserRepository(_context);
            Statuses = new StatusRepository(_context);
        }


        public ISampleRepository Samples { get; private set; }
        public IUserRepository Users { get; private set; }

        public IStatusRepository Statuses { get; private set; }

        public int Complete()
        {
            return _context.SaveChanges();
        }


        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
