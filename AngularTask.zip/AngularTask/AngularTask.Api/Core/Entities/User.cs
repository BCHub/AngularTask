﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace  AngularTask.Api.Core.Entities
{
    public partial class User
    {
        public User()
        {
            Sample = new HashSet<Sample>();
        }

        public long Id { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string FirstName { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string LastName { get; set; }

        [InverseProperty("CreatedByNavigation")]
        public virtual ICollection<Sample> Sample { get; set; }
    }
}
