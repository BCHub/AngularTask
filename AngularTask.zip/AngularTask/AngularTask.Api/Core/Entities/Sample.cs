﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace  AngularTask.Api.Core.Entities
{
    public partial class Sample
    {
        public long Id { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string Barcode { get; set; }
        [Required]
        [Column(TypeName = "DateTime")]
        public DateTime CreatedAt { get; set; }
        public long CreatedBy { get; set; }
        public long StatusId { get; set; }

        [ForeignKey("CreatedBy")]
        [InverseProperty("Sample")]
        public virtual User CreatedByNavigation { get; set; }
        [ForeignKey("StatusId")]
        [InverseProperty("Sample")]
        public virtual Status Status { get; set; }
    }
}
