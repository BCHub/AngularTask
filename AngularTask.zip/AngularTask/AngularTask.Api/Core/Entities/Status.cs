﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace  AngularTask.Api.Core.Entities
{
    public partial class Status
    {
        public Status()
        {
            Sample = new HashSet<Sample>();
        }

        public long Id { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string StatusName { get; set; }

        [InverseProperty("Status")]
        public virtual ICollection<Sample> Sample { get; set; }
    }
}
