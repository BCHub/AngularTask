﻿using AngularTask.Api.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularTask.Api.Core
{
    public interface IUnitOfWork : IDisposable
    {
        ISampleRepository Samples { get; }
        IUserRepository Users { get; }

        IStatusRepository Statuses { get; }
        int Complete();
    }
}
