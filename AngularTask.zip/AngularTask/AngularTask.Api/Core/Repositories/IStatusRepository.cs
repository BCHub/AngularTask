﻿using AngularTask.Api.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularTask.Api.Core.Repositories
{
    public interface IStatusRepository : IRepositoryBase<Status>
    {
        IEnumerable<Status> GetStatusWithSamplesAndUsers();
    }
}
