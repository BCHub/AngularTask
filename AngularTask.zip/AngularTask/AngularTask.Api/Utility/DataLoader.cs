﻿using AngularTask.Api.Concrete;
using AngularTask.Api.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularTask.Api.Utility
{
    public class DataLoader
    {

        public void LoadUsers()
        {
            List<User> lstUsers = new List<User>();
            string[] arrUsers = System.IO.File.ReadAllLines("App_Data/Users.txt");
            for (int i = 1; i < arrUsers.Length; i++)
            {
                string[] dateRow = arrUsers[i].Split(',');

                lstUsers.Add(new User() { FirstName = dateRow[1], LastName = dateRow[2] } );
            }

            using (var unitOfWork = new UnitOfWork(new TaskDbContext()))
            {
                unitOfWork.Users.InsertRange(lstUsers);
                unitOfWork.Complete();
            }
        }



        public void LoadStatuses()
        {
            List<Status> lstStatus = new List<Status>();
            string[] arrStatus = System.IO.File.ReadAllLines("App_Data/Statuses.txt");
            for (int i = 1; i < arrStatus.Length; i++)
            {
                string[] dateRow = arrStatus[i].Split(',');
                lstStatus.Add(new Status() { StatusName = dateRow[1] });
            }

            using (var unitOfWork = new UnitOfWork(new TaskDbContext()))
            {
                unitOfWork.Statuses.InsertRange(lstStatus);
                unitOfWork.Complete();
            }
        }


        public void LoadSamples()
        {
            List<Sample> lstSample = new List<Sample>();
            string[] arrSamples = System.IO.File.ReadAllLines("App_Data/Samples.txt");
            for (int i = 1; i < arrSamples.Length; i++)
            {
                string[] dateRow = arrSamples[i].Split(',');
                lstSample.Add(new Sample()
                {
                    Barcode = dateRow[1],
                    CreatedAt = DateTime.ParseExact(dateRow[2], "yyyy-MM-dd", null),
                    CreatedBy = (Convert.ToInt32(dateRow[3]) + 1),
                    StatusId = (Convert.ToInt32(dateRow[4]) + 1)
                });
            }

            using (var unitOfWork = new UnitOfWork(new TaskDbContext()))
            {
                unitOfWork.Samples.InsertRange(lstSample);
                unitOfWork.Complete();               
            }
        }

    }
}
