﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngularTask.Api.DTOs
{
    public class SampleDto
    {
        public long UserId { get; set; }
        public string User { get; set; }
        public string Barcode { get; set; }
        public string DateCreated { get; set; }
        public long StatusId { get; set; }
        public string Status { get; set; }
    }
}
