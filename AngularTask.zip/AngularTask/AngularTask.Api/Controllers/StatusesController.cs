﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using AngularTask.Api.Core.Entities;
using AngularTask.Api.Services.Concrete;



namespace AngularTask.Api.Controllers
{
    [EnableCors("ApiCrosPolicy")]
    [Route("api/[controller]")]
    public class StatusesController : Controller
    {
        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            var status = new StatusService().GetStatusDtos();
           
            if (!status.Any())
                return Content("No Data Available");
            return Ok(status);
        }
    }
}
