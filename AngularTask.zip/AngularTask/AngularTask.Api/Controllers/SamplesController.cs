﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AngularTask.Api.Concrete;
using AngularTask.Api.Utility;
using AngularTask.Api.Services;
using AngularTask.Api.Services.Concrete;
using AngularTask.Api.Core.Entities;
using Microsoft.AspNetCore.Cors;

namespace AngularTask.Api.Controllers
{
    [EnableCors("ApiCrosPolicy")]
    [Route("api/[controller]")]
    public class SamplesController : Controller
    {

       

        // GET Samples With Users and Statuses
        [HttpGet]
        public IActionResult Get()
        {        

            var samples = new SampleService().GetSampleDtos();
            if (!samples.Any())
                return Content("No Data Available");
            return Ok(samples);
           
        }



        [HttpGet("statuses/{statusId:int}")]
        public IActionResult Get(int statusId)
        {

            var samples = new SampleService().GetSampleDtos().Where(x => x.StatusId == (long) statusId);
            if (!samples.Any())
                return Content("No Data Available");
            return Ok(samples);

        }




        // POST Add a Sample with User and Status
        [HttpPost]
        public IActionResult Post([FromBody]Sample sample)
        {
            try
            {
                new SampleService().AddSample(sample);
                return Created("", null);
            }
            catch(Exception ex)
            {
                return BadRequest("Sample was NOT saved. [ Error Message: "+ ex.Message + "]");
            }
        }






























        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
